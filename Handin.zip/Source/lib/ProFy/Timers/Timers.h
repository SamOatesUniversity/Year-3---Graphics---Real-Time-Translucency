#ifndef PROFY_HEADER_TIMERS
#define PROFY_HEADER_TIMERS

#include "TimerBase.h"
#include "TimerCPU.h"
#include "TimerOpenGL.h"

#endif
