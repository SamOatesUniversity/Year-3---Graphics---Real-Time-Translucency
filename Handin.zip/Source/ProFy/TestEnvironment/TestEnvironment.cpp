// TestEnvironment.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <iostream>

#include <ProFy.h>

int _tmain(int argc, _TCHAR* argv[])
{
	ProFy *const profy = &ProFy::GetInstance();

	std::vector<ProFy::TimerID> timerIDs;
	
	static const unsigned int noofSleeps = 100;
	static const unsigned int maxSleepTime = 1000;

	ProFy::TimerID cpuTimerExpected;
	if (!profy->CreateTimer(cpuTimerExpected, ProFy::TimerType::CPU, "Expected Sleep Time"))
	{
		std::cout << "Failed to create CPU timer! " << __FILE__ << ", " << __LINE__ << "\n";
		system("PAUSE");
		return 0;
	}

	ProFy::TimerID cpuTimerActual;
	if (!profy->CreateTimer(cpuTimerActual, ProFy::TimerType::CPU, "Actual Sleep Time"))
	{
		std::cout << "Failed to create CPU timer! " << __FILE__ << ", " << __LINE__ << "\n";
		system("PAUSE");
		return 0;
	}

	timerIDs.push_back(cpuTimerActual);
	timerIDs.push_back(cpuTimerExpected);

	for (unsigned int sleepIndex = 0; sleepIndex < noofSleeps; ++sleepIndex)
	{
		const unsigned int sleepLength = (rand() % maxSleepTime) + 1;
		profy->StartTimer(cpuTimerActual);
		Sleep(sleepLength);
		profy->EndTimer(cpuTimerActual);

		profy->AddFakeResult(cpuTimerExpected, sleepLength);

		std::cout << "CPU Timer \"Sleep(" << sleepLength << ")\" Result: " << profy->GetTimerResult(cpuTimerActual) << "ms.\n";
	}

	profy->OutputTimers(timerIDs, true);

	system("PAUSE");
	return 0;
}

