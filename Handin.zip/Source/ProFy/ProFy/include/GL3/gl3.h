/* a fake gl3.h to redirect to the new glcorearb.h replacement */
#include "../GL/glcorearb.h"
