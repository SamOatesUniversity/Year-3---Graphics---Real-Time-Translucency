Name: 		Sam Oates
UserID: 	J906028
Test Machine: 	SCM-69314

Note:
I have modified the framework/Window.cpp so that tweakbar can handle mouse and keyboard input.
The relative licenses for tweakbar can be found in the /lib/AntTweakBar/ folder. 
Should you recieve an error about a missing dll, it can be found in the folder above.

Finally I have separated my profiling code out into a standalone solution. Of which I have built into a lib.
The lib can be found within \lib\ProFy\. Along with this the full source and solution can be found within the
\ProFy\ folder.